-- begin BPROC_USER_GROUP
create table BPROC_USER_GROUP (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    NAME varchar(255) not null,
    CODE varchar(255) not null,
    DESCRIPTION longvarchar,
    TYPE_ varchar(50) not null,
    --
    primary key (ID)
)^
-- end BPROC_USER_GROUP
-- begin BPROC_USER_GROUP_ROLE_LINK
create table BPROC_USER_GROUP_ROLE_LINK (
    USER_GROUP_ID varchar(36) not null,
    ROLE_ID varchar(36) not null,
    primary key (USER_GROUP_ID, ROLE_ID)
)^
-- end BPROC_USER_GROUP_ROLE_LINK
-- begin BPROC_USER_GROUP_USER_LINK
create table BPROC_USER_GROUP_USER_LINK (
    USER_GROUP_ID varchar(36) not null,
    USER_ID varchar(36) not null,
    primary key (USER_GROUP_ID, USER_ID)
)^
-- end BPROC_USER_GROUP_USER_LINK
-- begin BPROC_CONTENT_STORAGE
create table BPROC_CONTENT_STORAGE (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    NAME varchar(1000) not null,
    CONTENT longvarbinary,
    TYPE_ varchar(255),
    AUTHOR_ID varchar(36),
    --
    primary key (ID)
)^
-- end BPROC_CONTENT_STORAGE
