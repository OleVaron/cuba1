-- begin BPROC_USER_GROUP
create table BPROC_USER_GROUP (
    ID uuid,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    NAME varchar(255) not null,
    CODE varchar(255) not null,
    DESCRIPTION text,
    TYPE_ varchar(50) not null,
    --
    primary key (ID)
)^
-- end BPROC_USER_GROUP
-- begin BPROC_USER_GROUP_USER_LINK
create table BPROC_USER_GROUP_USER_LINK (
    USER_GROUP_ID uuid,
    USER_ID uuid,
    primary key (USER_GROUP_ID, USER_ID)
)^
-- end BPROC_USER_GROUP_USER_LINK
-- begin BPROC_USER_GROUP_ROLE_LINK
create table BPROC_USER_GROUP_ROLE_LINK (
    USER_GROUP_ID uuid,
    ROLE_ID uuid,
    primary key (USER_GROUP_ID, ROLE_ID)
)^
-- end BPROC_USER_GROUP_ROLE_LINK
-- begin BPROC_CONTENT_STORAGE
create table BPROC_CONTENT_STORAGE (
    ID uuid,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    NAME varchar(1000) not null,
    CONTENT bytea,
    TYPE_ varchar(255),
    AUTHOR_ID uuid,
    --
    primary key (ID)
)^
-- end BPROC_CONTENT_STORAGE
